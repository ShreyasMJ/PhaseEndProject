package movieTicket;


import java.util.Scanner;

public class MovieTicketBookingApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Assume a default username and password for simplicity
        FrontDesk frontDesk = new FrontDesk("Shreyas", "Shreyas123", new Theatre());

        // Login
        System.out.print("Enter username: ");
        String enteredUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String enteredPassword = scanner.nextLine();

        if (enteredUsername.equals(frontDesk.getUsername()) && frontDesk.login(enteredPassword)) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Invalid credentials. Exiting...");
            return;
        }

        int choice;
        do {
            displayOptions();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    updatePassword(frontDesk, scanner);
                    break;
                case 2:
                    viewSeatingArrangement(frontDesk, scanner);
                    break;
                case 3:
                    bookTicket(frontDesk, scanner);
                    break;
                case 4:
                    checkBookingStatus(frontDesk);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 5);

        scanner.close();
    }

    private static void displayOptions() {
        System.out.println("1. Update Password");
        System.out.println("2. View Seating Arrangement");
        System.out.println("3. Book Ticket");
        System.out.println("4. Check Booking Status");
        System.out.println("5. Exit");
    }

    private static void updatePassword(FrontDesk frontDesk, Scanner scanner) {
        System.out.print("Enter the new password: ");
        String newPassword = scanner.next();
        frontDesk.updatePassword(newPassword);
    }

    private static void viewSeatingArrangement(FrontDesk frontDesk, Scanner scanner) {
        System.out.print("Enter the date: ");
        String date = scanner.next();

        System.out.print("Enter the show time: ");
        String showTime = scanner.next();

        frontDesk.viewSeatingArrangement(date, showTime);
    }

    private static void bookTicket(FrontDesk frontDesk, Scanner scanner) {
        System.out.print("Enter the date: ");
        String date = scanner.next();

        System.out.print("Enter the show time: ");
        String showTime = scanner.next();

        frontDesk.bookTicket(date, showTime);
    }

    private static void checkBookingStatus(FrontDesk frontDesk) {
        frontDesk.checkBookingStatus();
    }
}

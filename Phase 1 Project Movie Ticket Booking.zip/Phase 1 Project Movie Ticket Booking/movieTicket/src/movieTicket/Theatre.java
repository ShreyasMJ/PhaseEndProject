package movieTicket;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Theatre {
    private Map<String, Map<String, SeatStatus>> bookingData; // date -> showTime -> seat -> status
    private Map<String, Double> seatPrices; // seat -> price

    public Theatre() {
        this.bookingData = new HashMap<>();
        this.seatPrices = new HashMap<>();
        initializeSeatPrices();
    }

    private void initializeSeatPrices() {
        // Add seat prices based on your requirements
        seatPrices.put("B1", 10.0);
        seatPrices.put("B2", 10.0);
        seatPrices.put("B3", 10.0);
        seatPrices.put("B4", 12.0);
        seatPrices.put("B5", 12.0);
        seatPrices.put("B6", 15.0);
    }

    public void displaySeatingArrangement(String date, String showTime) {
        // Display the seating arrangement for the specified date and show time
        // Implementation based on your requirements
    }

    public boolean bookTicket(String date, String showTime, String seatSelection) {
        // Implement logic to book the ticket for the specified date, show time, and seat selection
        // Return true if booking is successful, false otherwise
        return false;
    }

    public void displayTotalAmount(String date, String showTime, String seatSelection) {
        // Implement logic to calculate and display the total amount for the booking
        // Use seatPrices map to get the price for each selected seat
    }

    public void displayBookingStatus() {
        // Display the booking status based on the stored data
        // Implementation based on your requirements
    }
}

enum SeatStatus {
    AVAILABLE,
    BOOKED,
    RESERVED
}


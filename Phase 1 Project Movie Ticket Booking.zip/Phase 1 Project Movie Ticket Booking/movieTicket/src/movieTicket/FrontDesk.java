package movieTicket;
import java.util.Scanner;

public class FrontDesk {
    private String username;
    private String password;
    private Theatre theatre;

    public FrontDesk(String username, String password, Theatre theatre) {
        this.username = username;
        this.password = password;
        this.theatre = theatre;
    }


    public String getUsername() {
        return username;
    }
    
    public boolean login(String enteredPassword) {
        return password.equals(enteredPassword);
    }

    public void updatePassword(String newPassword) {
        this.password = newPassword;
        System.out.println("Password updated successfully.");
    }

    public void viewSeatingArrangement(String date, String showTime) {
        theatre.displaySeatingArrangement(date, showTime);
    }

    public void bookTicket(String date, String showTime) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the preferred seat(s): ");
        String seatSelection = scanner.nextLine();

        if (theatre.bookTicket(date, showTime, seatSelection)) {
            System.out.println("Ticket booked successfully!");
            theatre.displayTotalAmount(date, showTime, seatSelection);
        } else {
            System.out.println("Ticket booking failed. Please try again.");
        }
    }

    public void checkBookingStatus() {
        theatre.displayBookingStatus();
    }
}
